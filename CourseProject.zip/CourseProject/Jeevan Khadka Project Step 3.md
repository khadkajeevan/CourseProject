##Expense Tracker
##Jeevan Khadka 
##15 July 2019

                                 #Project Step 3: High Level Requirements 


This expense trackers main goal is to manage the budget and expenses which will encourage the concept of saving and responsibly spending the money. 
This expense tracker software will have many features which will help to manage people’s monthly budget.  It will have a section where you can input
your targeted monthly budget.Once an individual makes an expense such as grocery, rent, phone bill, gas, miscellaneous expenses. They will come back
to app and record those expenses. Application software will then calculate how much you have spent and how much you have left for the rest of the month.
It will give you how much percentage of your budget has been spent and percentage left for the rest of the month.  You can set a warning message when 
you have certain percent left on your budget.One can refer to their app and see where they are standing in their monthly budget and will adjust according
to meet their monthly goal. App will generate a monthly report on individual’s expenses and can compare to previous month’s report. 


**MVP**:
For this application to work at minimum it should have a section where you can input your targeted expenses for the month and a section where you
can input all your expenses. This way the app will be able to calculate the amount of money spent in reference to amount that has been allocated for the
month. This way the app will be able to tell you the percentage that has been spent and remaining. 

**Full**:
For the product to be full and shippable, it should be able to let the customers to create and account with all their information. 
This app will use the information such as email address to send the report at the end of the month to customer regarding their expenditure for
the month letting them know if they were able to meet their target or not. It will also compare the report from previous month.  Along with 
the section for target budget and expenditure, there will be section where the customer can input their bank balance so that it can automatically
deduct the amount spent front the total cash balance, they have letting the customer know the remaining balance. This will provide a clear picture
to customers about their financial position. 

**Stretch**:
Apart from the full features of the products, there will always be some features which will be nice to have but not necessarily required
for the application to work.  For the expense tracker app, it will be nice to have different sections for expenditure such as grocery, gas, rent, 
credit card etc., rather than having all the expenses list under one section. If this feature is in the app, it will provide even a clear picture
to customer as it focuses on different category of their expenses.  It will be nice to have a section where customer can input the payment reminder 
 for the rent, monthly credit card etc. 




     
