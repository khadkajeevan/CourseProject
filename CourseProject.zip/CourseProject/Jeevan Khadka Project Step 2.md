##Expense Tracker
##Jeevan Khadka 
##10 July 2019

                                 #Project Step 2: Customer Need Statement

Managing money is one of the main priorities of many individuals.  Every individual including single man/ woman, married couples, old age people 
wants to know their financial position so that they can spend their money accordingly. If not well managed, money can be overspent without knowing
and it will  be very hard to save money without tracking expenses. 						



The main need of expense tracker is to make your budget work for you.  There is no way you can tell whether you have overspent each month/week,if 
you do not know how much you have spent.  There are so many small expenses which contributes to blow somebody’s budget.  There are many ways
to track the expenses. One can write ledgers or check every account such as checking, saving and credit cards in order to track the expenses. 
Since everyone has smart phone these days it will be easier track all expenses with the help of a single application. On one hand it will help
to control the expenses whereas on other hand it will help to save money.  Many people have difficulties to manage their income and expenses 
leading them to debt and credit card balance. Saving money has been a bigger challenge to everyone. Even people who earns more struggles to 
manage their budget and leaves them with no saving.  The main purpose of this software is to help people to manage their budget, expenses and 
saving so that they can be financially strong. 


This software has very high group of intended users. Money is an important aspect to everyone and managing it has been more challenging.
Single man/ woman, married couples, old individuals and even young people want’s to m manage their budget so that they spent accordingly.
If we don’t know how much we spent, there is always a chance we can over spent.  The main targeted age group for this app is 18-50 years.
Budgeting starts as soon as you start earning money and supporting yourself.  Many people will start living independently as soon as they finish 
high school and put themselves through college while working. Managing their budget will be important for them. Not only young people but also 
for married and employed people it is extremely necessary to manage their money so that they save instead of overspending. 



This expense tracker software will have many features which will help to manage people’s monthly budget.  It will have a section where you can 
input your targeted monthly budget. Once an individual makes an expense such as grocery, rent, phone bill, gas, miscellaneous expenses etc, they
will come back to app and record those expenses. Application software will then calculate how much you have spent and how much you have left for
the rest of the month. It will give you how much percentage of your budget has been spent and percentage left for the rest of the month.  You can 
set a warning message when you have 10-20 percent left on your budget.  One can refer to their app and see where they are standing in their monthly 
budget and will adjust according to meet their monthly goal. App will generate a monthly report on individual’s expenses and can compare to previous 
month’s report. 
 
 








     
