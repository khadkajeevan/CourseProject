# Project Step 1

1.  Messaging System - **To Do List Application**
	Notification, Calendar, Alert, Reports completed and overdue	
	Example Application: nTask, Microsoft To-Do
    This application will keep track of everyday to do tasks. It will send alert based on upcoming, completed and overdue tasks. It will have ability to sync with the outlook, gmail calendars to track appointments and other stuffs like homeworks.
    It will notify of your events and to do list such as grocery, homeworks and also remind you of overdue tasks. It will also send you weekly report on our upcoming tasks as well as completed tasks.
    This app will be useful for everyone as we all have some tasks that have a due date and we tend to forget to do it. 

2. Electronic Learning Session - **Expenses Tracker**
    Expenses record per different expense category, Budget plan, Alerts and Notify of budget limit or over expenditure  
    Example Applications: Spending Tracker, Mint, YNAB
    This is an expense tracker application. It can plan a monthly expenditure based on your expenses in different catagories and alert you if you are over your limit or over spending on one catagories and send you monthly report of your expenditure based on your limit.
	

3. Online Store – **Online Shopping**
   Inventory Display and control, Payement method, 
   Example Application: Amazon, Ebay
   This is an online store where you can buy different new and used items.

4. **Calculator**
    This is a calculator where you can do different mathematical calculations such as add, subtract etc